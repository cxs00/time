//
//  timeApp.swift
//  TIME
//
//  TIME - 时间管理 App 入口
//

import SwiftUI

@main
struct timeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
